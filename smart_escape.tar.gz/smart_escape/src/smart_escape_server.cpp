#include "smart_escape/smart_escape_server.hpp"
#include <cmath>
#include <vector>
#include <algorithm>

namespace smart_escape
{

SmartEscapeServer::SmartEscapeServer(const rclcpp::NodeOptions & options)
: Node("smart_escape_server", options)
{
  // 声明参数
  declare_parameter("global_frame", "map");
  declare_parameter("robot_base_frame", "base_link");
  declare_parameter("initial_radius", 0.5);      // 初始搜索半径
  declare_parameter("max_radius", 2.0);          // 最大搜索半径
  declare_parameter("radius_increment", 0.3);    // 半径增量
  declare_parameter("min_free_cells_threshold", 10); // 最小无障碍栅格阈值
  declare_parameter("escape_distance", 0.3);     // 脱困移动距离
  declare_parameter("transform_tolerance", 0.1);
  
  // 获取参数
  global_frame_ = get_parameter("global_frame").as_string();
  robot_base_frame_ = get_parameter("robot_base_frame").as_string();
  initial_radius_ = get_parameter("initial_radius").as_double();
  max_radius_ = get_parameter("max_radius").as_double();
  radius_increment_ = get_parameter("radius_increment").as_double();
  min_free_cells_threshold_ = get_parameter("min_free_cells_threshold").as_int();
  escape_distance_ = get_parameter("escape_distance").as_double();
  transform_tolerance_ = get_parameter("transform_tolerance").as_double();
  
  // 初始化TF
  tf_buffer_ = std::make_shared<tf2_ros::Buffer>(get_clock());
  tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
  
  // 订阅代价地图 - 使用全局代价地图
  costmap_sub_ = create_subscription<nav_msgs::msg::OccupancyGrid>(
    "/global_costmap/costmap",
    rclcpp::QoS(1).transient_local().reliable(),
    std::bind(&SmartEscapeServer::costmapCallback, this, std::placeholders::_1));
  
  // 创建Action服务器
  action_server_ = rclcpp_action::create_server<SmartEscape>(
    this,
    "smart_escape",
    std::bind(&SmartEscapeServer::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
    std::bind(&SmartEscapeServer::handle_cancel, this, std::placeholders::_1),
    std::bind(&SmartEscapeServer::handle_accepted, this, std::placeholders::_1));
  
  RCLCPP_INFO(get_logger(), "Smart Escape Server initialized");
  RCLCPP_INFO(get_logger(), "Parameters: initial_radius=%.2f, max_radius=%.2f, escape_distance=%.2f",
              initial_radius_, max_radius_, escape_distance_);
}

void SmartEscapeServer::costmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(costmap_mutex_);
  current_costmap_ = msg;
}

rclcpp_action::GoalResponse SmartEscapeServer::handle_goal(
  const rclcpp_action::GoalUUID & uuid,
  std::shared_ptr<const SmartEscape::Goal> goal)
{
  RCLCPP_INFO(get_logger(), "Received smart escape request");
  (void)uuid;
  (void)goal;
  return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

rclcpp_action::CancelResponse SmartEscapeServer::handle_cancel(
  const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  RCLCPP_INFO(get_logger(), "Received cancel request");
  (void)goal_handle;
  return rclcpp_action::CancelResponse::ACCEPT;
}

void SmartEscapeServer::handle_accepted(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  // 在新线程中执行脱困逻辑
  std::thread{std::bind(&SmartEscapeServer::execute_escape, this, std::placeholders::_1), goal_handle}.detach();
}

void SmartEscapeServer::execute_escape(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  RCLCPP_INFO(get_logger(), "Executing smart escape...");
  
  auto result = std::make_shared<SmartEscape::Result>();
  
  // 检查代价地图是否可用
  {
    std::lock_guard<std::mutex> lock(costmap_mutex_);
    if (!current_costmap_) {
      RCLCPP_ERROR(get_logger(), "Costmap not available");
      result->success = false;
      result->message = "Costmap not available";
      goal_handle->abort(result);
      return;
    }
  }
  
  // 获取机器人当前位姿
  geometry_msgs::msg::Pose robot_pose;
  if (!getRobotPose(robot_pose)) {
    RCLCPP_ERROR(get_logger(), "Failed to get robot pose");
    result->success = false;
    result->message = "Failed to get robot pose";
    goal_handle->abort(result);
    return;
  }
  
  // 计算脱困目标点（川大算法核心）
  geometry_msgs::msg::PoseStamped escape_pose;
  if (!compute_escape_target(robot_pose, escape_pose)) {
    RCLCPP_ERROR(get_logger(), "Failed to compute escape target");
    result->success = false;
    result->message = "Failed to compute escape target";
    goal_handle->abort(result);
    return;
  }
  
  // 检查是否被取消
  if (goal_handle->is_canceling()) {
    result->success = false;
    result->message = "Cancelled";
    goal_handle->canceled(result);
    return;
  }
  
  // 返回结果
  result->success = true;
  result->message = "Escape target computed successfully";
  result->escape_pose = escape_pose;
  
  RCLCPP_INFO(get_logger(), "Smart escape target: [%.3f, %.3f]", 
              escape_pose.pose.position.x, escape_pose.pose.position.y);
  
  goal_handle->succeed(result);
}

/**
 * 川大火锅战队脱困算法核心实现
 * 
 * 算法步骤：
 * 1. 以机器人为中心，计算一定半径圆内代价地图数值为0（无障碍）的栅格数
 * 2. 若无障碍栅格数量低于阈值，则扩大半径再次统计
 * 3. 若高于阈值，则计算所有圆内无障碍栅格的平均坐标
 * 4. 根据平均坐标和机器人当前位置的关系，计算脱困目标点
 */
bool SmartEscapeServer::compute_escape_target(
  const geometry_msgs::msg::Pose & robot_pose,
  geometry_msgs::msg::PoseStamped & escape_pose)
{
  std::lock_guard<std::mutex> lock(costmap_mutex_);
  
  if (!current_costmap_) {
    return false;
  }
  
  // 将机器人世界坐标转换为地图坐标
  unsigned int robot_mx, robot_my;
  if (!worldToMap(robot_pose.position.x, robot_pose.position.y, robot_mx, robot_my)) {
    RCLCPP_ERROR(get_logger(), "Robot pose is outside costmap bounds");
    return false;
  }
  
  // 获取机器人朝向
  tf2::Quaternion q;
  tf2::fromMsg(robot_pose.orientation, q);
  tf2::Matrix3x3 m(q);
  double roll, pitch, yaw;
  m.getRPY(roll, pitch, yaw);
  
  // 逐步扩大搜索半径
  double current_radius = initial_radius_;
  std::vector<std::pair<unsigned int, unsigned int>> free_cells;
  
  while (current_radius <= max_radius_) {
    free_cells.clear();
    
    // 将半径转换为栅格数
    int radius_cells = static_cast<int>(current_radius / current_costmap_->info.resolution);
    
    // 在圆形区域内搜索无障碍栅格
    for (int dy = -radius_cells; dy <= radius_cells; ++dy) {
      for (int dx = -radius_cells; dx <= radius_cells; ++dx) {
        // 检查是否在圆内
        if (dx * dx + dy * dy > radius_cells * radius_cells) {
          continue;
        }
        
        int mx = static_cast<int>(robot_mx) + dx;
        int my = static_cast<int>(robot_my) + dy;
        
        // 检查边界
        if (mx < 0 || mx >= static_cast<int>(current_costmap_->info.width) ||
            my < 0 || my >= static_cast<int>(current_costmap_->info.height)) {
          continue;
        }
        
        // 检查是否为无障碍栅格（代价为0）
        int cost = getCost(static_cast<unsigned int>(mx), static_cast<unsigned int>(my));
        if (cost == 0) {
          free_cells.emplace_back(static_cast<unsigned int>(mx), static_cast<unsigned int>(my));
        }
      }
    }
    
    RCLCPP_DEBUG(get_logger(), "Radius %.2f: found %zu free cells (threshold: %d)",
                 current_radius, free_cells.size(), min_free_cells_threshold_);
    
    // 检查是否满足阈值
    if (static_cast<int>(free_cells.size()) >= min_free_cells_threshold_) {
      break;
    }
    
    // 扩大半径继续搜索
    current_radius += radius_increment_;
  }
  
  // 检查是否找到足够的无障碍栅格
  if (static_cast<int>(free_cells.size()) < min_free_cells_threshold_) {
    RCLCPP_WARN(get_logger(), "Not enough free cells found (found %zu, need %d)",
                free_cells.size(), min_free_cells_threshold_);
    return false;
  }
  
  RCLCPP_INFO(get_logger(), "Found %zu free cells within radius %.2f", 
              free_cells.size(), current_radius);
  
  // 计算所有无障碍栅格的平均坐标（质心）
  double avg_mx = 0.0, avg_my = 0.0;
  for (const auto & cell : free_cells) {
    avg_mx += cell.first;
    avg_my += cell.second;
  }
  avg_mx /= free_cells.size();
  avg_my /= free_cells.size();
  
  // 将平均坐标转换回世界坐标
  double avg_wx, avg_wy;
  mapToWorld(static_cast<unsigned int>(avg_mx), static_cast<unsigned int>(avg_my), avg_wx, avg_wy);
  
  RCLCPP_INFO(get_logger(), "Free space centroid: [%.3f, %.3f]", avg_wx, avg_wy);
  
  // 计算从机器人指向质心的方向向量
  double dx = avg_wx - robot_pose.position.x;
  double dy = avg_wy - robot_pose.position.y;
  double distance = std::sqrt(dx * dx + dy * dy);
  
  // 如果质心就在机器人位置附近，使用机器人当前朝向
  double escape_yaw;
  if (distance < 0.01) {
    escape_yaw = yaw;
    RCLCPP_WARN(get_logger(), "Centroid is at robot position, using current heading");
  } else {
    escape_yaw = std::atan2(dy, dx);
  }
  
  // 计算脱困目标点：沿质心方向移动escape_distance_
  escape_pose.header.frame_id = global_frame_;
  escape_pose.header.stamp = now();
  escape_pose.pose.position.x = robot_pose.position.x + escape_distance_ * std::cos(escape_yaw);
  escape_pose.pose.position.y = robot_pose.position.y + escape_distance_ * std::sin(escape_yaw);
  escape_pose.pose.position.z = 0.0;
  
  // 设置朝向为脱困方向
  tf2::Quaternion escape_q;
  escape_q.setRPY(0, 0, escape_yaw);
  escape_pose.pose.orientation = tf2::toMsg(escape_q);
  
  RCLCPP_INFO(get_logger(), "Escape target computed: [%.3f, %.3f], heading: %.2f deg",
              escape_pose.pose.position.x, escape_pose.pose.position.y, 
              escape_yaw * 180.0 / M_PI);
  
  return true;
}

bool SmartEscapeServer::getRobotPose(geometry_msgs::msg::Pose & robot_pose)
{
  geometry_msgs::msg::TransformStamped transform;
  try {
    transform = tf_buffer_->lookupTransform(
      global_frame_, robot_base_frame_,
      tf2::TimePointZero,
      tf2::durationFromSec(transform_tolerance_));
  } catch (tf2::TransformException & ex) {
    RCLCPP_ERROR(get_logger(), "Transform error: %s", ex.what());
    return false;
  }
  
  robot_pose.position.x = transform.transform.translation.x;
  robot_pose.position.y = transform.transform.translation.y;
  robot_pose.position.z = transform.transform.translation.z;
  robot_pose.orientation = transform.transform.rotation;
  
  return true;
}

bool SmartEscapeServer::worldToMap(double wx, double wy, unsigned int & mx, unsigned int & my)
{
  if (!current_costmap_) {
    return false;
  }
  
  double origin_x = current_costmap_->info.origin.position.x;
  double origin_y = current_costmap_->info.origin.position.y;
  double resolution = current_costmap_->info.resolution;
  
  if (wx < origin_x || wy < origin_y) {
    return false;
  }
  
  mx = static_cast<unsigned int>((wx - origin_x) / resolution);
  my = static_cast<unsigned int>((wy - origin_y) / resolution);
  
  if (mx >= current_costmap_->info.width || my >= current_costmap_->info.height) {
    return false;
  }
  
  return true;
}

bool SmartEscapeServer::mapToWorld(unsigned int mx, unsigned int my, double & wx, double & wy)
{
  if (!current_costmap_) {
    return false;
  }
  
  double origin_x = current_costmap_->info.origin.position.x;
  double origin_y = current_costmap_->info.origin.position.y;
  double resolution = current_costmap_->info.resolution;
  
  wx = origin_x + (mx + 0.5) * resolution;
  wy = origin_y + (my + 0.5) * resolution;
  
  return true;
}

int SmartEscapeServer::getCost(unsigned int mx, unsigned int my)
{
  if (!current_costmap_) {
    return -1;
  }
  
  if (mx >= current_costmap_->info.width || my >= current_costmap_->info.height) {
    return -1;
  }
  
  return current_costmap_->data[my * current_costmap_->info.width + mx];
}

} // namespace smart_escape

#include "rclcpp_components/register_node_macro.hpp"
RCLCPP_COMPONENTS_REGISTER_NODE(smart_escape::SmartEscapeServer)
