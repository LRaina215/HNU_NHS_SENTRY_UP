#include "smart_escape/bt_smart_escape_node.hpp"
#include "behaviortree_cpp_v3/bt_factory.h"

namespace nav2_behavior_tree
{

BtSmartEscapeNode::BtSmartEscapeNode(
  const std::string & xml_tag_name,
  const BT::NodeConfiguration & conf)
: BT::StatefulActionNode(xml_tag_name, conf),
  goal_sent_(false),
  result_received_(false),
  goal_accepted_(false)
{
  // 获取ROS2节点
  node_ = config().blackboard->get<rclcpp::Node::SharedPtr>("node");
  
  // 获取端口参数
  getInput("server_name", server_name_);
  getInput("server_timeout", server_timeout_);
  
  // 创建Action客户端
  action_client_ = rclcpp_action::create_client<SmartEscape>(node_, server_name_);
  
  RCLCPP_INFO(node_->get_logger(), "BtSmartEscapeNode created, server: %s", server_name_.c_str());
}

BtSmartEscapeNode::~BtSmartEscapeNode()
{
  cleanup();
}

void BtSmartEscapeNode::cleanup()
{
  if (action_client_) {
    action_client_.reset();
  }
}

BT::NodeStatus BtSmartEscapeNode::onStart()
{
  RCLCPP_INFO(node_->get_logger(), "BtSmartEscapeNode starting...");
  
  // 重置状态
  goal_sent_ = false;
  result_received_ = false;
  goal_accepted_ = false;
  result_.reset();
  
  // 检查Action服务器是否可用
  if (!action_client_->wait_for_action_server(std::chrono::seconds(5))) {
    RCLCPP_ERROR(node_->get_logger(), "Smart escape action server not available");
    return BT::NodeStatus::FAILURE;
  }
  
  // 创建并发送Goal
  auto goal_msg = SmartEscape::Goal();
  
  RCLCPP_INFO(node_->get_logger(), "Sending smart escape goal...");
  
  auto send_goal_options = rclcpp_action::Client<SmartEscape>::SendGoalOptions();
  send_goal_options.goal_response_callback =
    std::bind(&BtSmartEscapeNode::goalResponseCallback, this, std::placeholders::_1);
  send_goal_options.result_callback =
    std::bind(&BtSmartEscapeNode::resultCallback, this, std::placeholders::_1);
  send_goal_options.feedback_callback =
    std::bind(&BtSmartEscapeNode::feedbackCallback, this, std::placeholders::_1, std::placeholders::_2);
  
  auto future_goal_handle = action_client_->async_send_goal(goal_msg, send_goal_options);
  
  goal_sent_ = true;
  
  // 返回RUNNING状态，等待结果
  return BT::NodeStatus::RUNNING;
}

BT::NodeStatus BtSmartEscapeNode::onRunning()
{
  // 检查结果是否收到
  if (result_received_) {
    if (result_ && result_->success) {
      RCLCPP_INFO(node_->get_logger(), "Smart escape succeeded: %s", result_->message.c_str());
      
      // 输出脱困目标点
      setOutput("escape_pose", result_->escape_pose);
      setOutput("result_message", result_->message);
      
      return BT::NodeStatus::SUCCESS;
    } else {
      RCLCPP_ERROR(node_->get_logger(), "Smart escape failed: %s", 
                   result_ ? result_->message.c_str() : "unknown error");
      
      setOutput("result_message", result_ ? result_->message : "unknown error");
      
      return BT::NodeStatus::FAILURE;
    }
  }
  
  // 检查是否超时
  // 这里可以添加超时检查逻辑
  
  // 继续等待
  return BT::NodeStatus::RUNNING;
}

void BtSmartEscapeNode::onHalted()
{
  RCLCPP_INFO(node_->get_logger(), "BtSmartEscapeNode halted");
  
  // 取消正在进行的Goal
  if (action_client_ && goal_sent_ && !result_received_) {
    action_client_->async_cancel_all_goals();
  }
  
  cleanup();
}

void BtSmartEscapeNode::goalResponseCallback(const ClientGoalHandle::SharedPtr & goal_handle)
{
  if (!goal_handle) {
    RCLCPP_ERROR(node_->get_logger(), "Smart escape goal was rejected by server");
    goal_accepted_ = false;
    result_received_ = true;  // 标记为完成（失败）
  } else {
    RCLCPP_INFO(node_->get_logger(), "Smart escape goal accepted by server");
    goal_accepted_ = true;
  }
}

void BtSmartEscapeNode::resultCallback(const ClientGoalHandle::WrappedResult & wrapped_result)
{
  result_received_ = true;
  
  switch (wrapped_result.code) {
    case rclcpp_action::ResultCode::SUCCEEDED:
      result_ = wrapped_result.result;
      break;
    case rclcpp_action::ResultCode::ABORTED:
      RCLCPP_ERROR(node_->get_logger(), "Smart escape goal was aborted");
      break;
    case rclcpp_action::ResultCode::CANCELED:
      RCLCPP_WARN(node_->get_logger(), "Smart escape goal was canceled");
      break;
    default:
      RCLCPP_ERROR(node_->get_logger(), "Unknown result code");
      break;
  }
}

void BtSmartEscapeNode::feedbackCallback(
  ClientGoalHandle::SharedPtr,
  const std::shared_ptr<const SmartEscape::Feedback> feedback)
{
  RCLCPP_DEBUG(node_->get_logger(), "Smart escape feedback: %s (%.1f%%)",
               feedback->status.c_str(), feedback->progress * 100.0);
}

} // namespace nav2_behavior_tree

// 注册节点
#include "behaviortree_cpp_v3/bt_factory.h"
BT_REGISTER_NODES(factory)
{
  factory.registerNodeType<nav2_behavior_tree::BtSmartEscapeNode>("SmartEscape");
}
