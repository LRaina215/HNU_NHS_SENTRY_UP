#ifndef SMART_ESCAPE_SERVER_HPP_
#define SMART_ESCAPE_SERVER_HPP_

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <nav2_msgs/action/smart_escape.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

namespace smart_escape
{

using SmartEscape = nav2_msgs::action::SmartEscape;
using GoalHandleSmartEscape = rclcpp_action::ServerGoalHandle<SmartEscape>;

class SmartEscapeServer : public rclcpp::Node
{
public:
  explicit SmartEscapeServer(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  // Action服务器
  rclcpp_action::Server<SmartEscape>::SharedPtr action_server_;
  
  // 代价地图订阅
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr costmap_sub_;
  nav_msgs::msg::OccupancyGrid::SharedPtr current_costmap_;
  std::mutex costmap_mutex_;
  
  // TF
  std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
  
  // 参数
  std::string global_frame_;
  std::string robot_base_frame_;
  double initial_radius_;
  double max_radius_;
  double radius_increment_;
  int min_free_cells_threshold_;
  double escape_distance_;
  double transform_tolerance_;
  
  // Action回调
  rclcpp_action::GoalResponse handle_goal(
    const rclcpp_action::GoalUUID & uuid,
    std::shared_ptr<const SmartEscape::Goal> goal);
  
  rclcpp_action::CancelResponse handle_cancel(
    const std::shared_ptr<GoalHandleSmartEscape> goal_handle);
  
  void handle_accepted(const std::shared_ptr<GoalHandleSmartEscape> goal_handle);
  
  // 核心脱困算法
  void execute_escape(const std::shared_ptr<GoalHandleSmartEscape> goal_handle);
  
  // 计算脱困目标点（川大算法核心）
  bool compute_escape_target(
    const geometry_msgs::msg::Pose & robot_pose,
    geometry_msgs::msg::PoseStamped & escape_pose);
  
  // 获取机器人当前位姿
  bool getRobotPose(geometry_msgs::msg::Pose & robot_pose);
  
  // 代价地图相关工具函数
  bool worldToMap(double wx, double wy, unsigned int & mx, unsigned int & my);
  bool mapToWorld(unsigned int mx, unsigned int my, double & wx, double & wy);
  int getCost(unsigned int mx, unsigned int my);
  
  // 代价地图回调
  void costmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg);
};

} // namespace smart_escape

#endif // SMART_ESCAPE_SERVER_HPP_
