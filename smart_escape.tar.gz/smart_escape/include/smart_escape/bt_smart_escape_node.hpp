#ifndef BT_SMART_ESCAPE_NODE_HPP_
#define BT_SMART_ESCAPE_NODE_HPP_

#include <string>
#include <memory>
#include <mutex>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "behaviortree_cpp_v3/action_node.h"
#include "nav2_msgs/action/smart_escape.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"

namespace nav2_behavior_tree
{

/**
 * @brief 智能脱困行为树节点
 * 
 * 这个节点封装了对SmartEscape Action的调用，可以在行为树中使用
 * 它不会阻塞bt_navigator的启动，因为Action调用是异步的
 */
class BtSmartEscapeNode : public BT::StatefulActionNode
{
public:
  BtSmartEscapeNode(
    const std::string & xml_tag_name,
    const BT::NodeConfiguration & conf);
  
  ~BtSmartEscapeNode() override;
  
  static BT::PortsList providedPorts()
  {
    return {
      BT::InputPort<std::string>("server_name", "smart_escape", "Action server name"),
      BT::InputPort<std::chrono::milliseconds>("server_timeout", std::chrono::milliseconds(10000), "Server timeout"),
      BT::OutputPort<geometry_msgs::msg::PoseStamped>("escape_pose", "Computed escape pose"),
      BT::OutputPort<std::string>("result_message", "Result message")
    };
  }

protected:
  // BT::StatefulActionNode接口
  BT::NodeStatus onStart() override;
  BT::NodeStatus onRunning() override;
  void onHalted() override;

private:
  using SmartEscape = nav2_msgs::action::SmartEscape;
  using ClientGoalHandle = rclcpp_action::ClientGoalHandle<SmartEscape>;
  
  // ROS2节点和Action客户端
  rclcpp::Node::SharedPtr node_;
  rclcpp_action::Client<SmartEscape>::SharedPtr action_client_;
  
  // 参数
  std::string server_name_;
  std::chrono::milliseconds server_timeout_;
  
  // Action状态
  bool goal_sent_;
  bool result_received_;
  bool goal_accepted_;
  SmartEscape::Result::SharedPtr result_;
  
  // 回调函数
  void goalResponseCallback(const ClientGoalHandle::SharedPtr & goal_handle);
  void resultCallback(const ClientGoalHandle::WrappedResult & result);
  void feedbackCallback(
    ClientGoalHandle::SharedPtr,
    const std::shared_ptr<const SmartEscape::Feedback> feedback);
  
  // 清理
  void cleanup();
};

} // namespace nav2_behavior_tree

#endif // BT_SMART_ESCAPE_NODE_HPP_
